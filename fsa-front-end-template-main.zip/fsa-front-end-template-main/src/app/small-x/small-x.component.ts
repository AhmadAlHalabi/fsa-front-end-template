import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-small-x',
  templateUrl: './small-x.component.html',
  styleUrls: ['./small-x.component.css']
})
export class SmallXComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
